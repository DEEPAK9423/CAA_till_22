#pragma once
#include "DSModule3.h"
#include "IHelloWorld.h"

class ExportedByDSModule3  CHelloWorld : public IHelloWorld
{
public:

	void greet(); 
};

