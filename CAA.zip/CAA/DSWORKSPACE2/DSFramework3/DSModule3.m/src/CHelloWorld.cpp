//#include "pch.h"
#include "CHelloWorld.h"
#include <iostream>
using namespace std;

void CHelloWorld::greet()
{
	cout << "Hello World!!" << endl;
}
