#include"CFactory.h"

IHelloWorld* CFactory::getHelloWorld()
{
   return new CHelloWorld();
}