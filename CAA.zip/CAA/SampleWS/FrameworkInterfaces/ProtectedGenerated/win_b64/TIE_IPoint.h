#ifndef __TIE_IPoint
#define __TIE_IPoint

#include <string.h>
#include "CATBaseUnknown.h"
#include "CATMetaClass.h"
#include "CATMacForTie.h"
#include "IPoint.h"
#include "JS0DSPA.h"
#include "DSYExport.h"


#define Exported DSYExport
#define Imported DSYImport


/* To link an implementation with the interface IPoint */
#define declare_TIE_IPoint(classe,TIE_Version) \
 \
      CATForwardDeclareTemplateFunctionSpecialization_##TIE_Version(classe) \
 \
class TIEIPoint##classe : public IPoint \
{ \
   private: \
      CATDeclareCommonTIEMembers2 \
   public: \
      CATDeclareTIEMethods(IPoint, classe) \
      CATDeclareIUnknownMethodsForCATBaseUnknownTIE \
      CATDeclareCATBaseUnknownMethodsForTIE \
};



#define ENVTIEdeclare_IPoint(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \


#define ENVTIEdefine_IPoint(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \


/* Name of the TIE class */
#define class_TIE_IPoint(classe)    TIEIPoint##classe


/* Common methods inside a TIE */
#define common_TIE_IPoint(classe,TIE_Version) \
 \
 \
/* Static initialization */ \
CATDefineCommonTIEMembers2(IPoint, classe) \
 \
 \
CATImplementTIEMethods(IPoint, classe) \
CATImplementIUnknownMethodsForCATBaseUnknownTIE(IPoint, classe, 1) \
CATImplementCATBaseUnknownMethodsForTIE(IPoint, classe) \
 \



/* Macro used to link an implementation with an interface */
#define Real_TIE_IPoint(classe,TIE_Version) \
 \
 \
declare_TIE_IPoint(classe,TIE_Version) \
 \
 \
common_TIE_IPoint(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIECreation(IPoint, classe) \
 \
 \
CATImplementTIEMeta(IPoint, classe, ENUMTypeOfClass::TIE, IPoint::MetaObject(), IPoint::MetaObject())


/* Macro used to link an implementation with an interface */
/* This TIE is chained on the implementation object */
#define Real_TIEchain_IPoint(classe,TIE_Version) \
 \
 \
declare_TIE_IPoint(classe,TIE_Version) \
 \
 \
common_TIE_IPoint(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIEchainCreation(IPoint, classe) \
 \
 \
CATImplementTIEMeta(IPoint, classe, ENUMTypeOfClass::TIEchain, IPoint::MetaObject(), IPoint::MetaObject())

/* Macro to switch between BOA and TIE at build time */ 
#ifdef CATSYS_BOA_IS_TIE
#define BOA_IPoint(classe) TIE_IPoint(classe)
#else
#define BOA_IPoint(classe) CATImplementBOA(IPoint, classe)
#endif


/* Macros used to link an implementation with an interface */
#define TIE_Deprecated_IPoint(classe) Real_TIE_IPoint(classe,TIEV1)
#define TIEchain_Deprecated_IPoint(classe) Real_TIEchain_IPoint(classe,TIEV1) 
#define TIE_IPoint(classe) Real_TIE_IPoint(classe,TIEV2)
#define TIEchain_IPoint(classe) Real_TIEchain_IPoint(classe,TIEV2) 

#endif
