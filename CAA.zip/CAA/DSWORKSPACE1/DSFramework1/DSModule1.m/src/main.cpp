
#include <iostream.h>
#include "IHelloWorld.h"
#include "CFactory.h"
#include "CATFactory.h"
#include "IPoint.h"
#include "ILine.h"
#include "IColor.h"
#include "I3DPoint.h"
#include "I4DPoint.h"

int main()
{
	cout << "Inside main" << endl;
	IPoint* piPointOnPoint=NULL;
	CATFactory::getPoint(IID_IPoint,(void**)&piPointOnPoint);
	I4DPoint* pi4DPointonPoint = NULL;
			HRESULT hr = piPointOnPoint->QueryInterface(IID_I4DPoint, (void**)&pi4DPointonPoint);
			if (S_OK == hr)
			{
				cout << "We are in Ford workspace" << endl;
				pi4DPointonPoint->setT(10.00);
				double x=0;
				pi4DPointonPoint->getT(x);
				cout<<x<<endl;
			}
			else
			{
				cout << "No Implementation" << endl;
			}
	// IPoint* piPointOnPoint = NULL;
	
	
	// HRESULT hr = CATFactory::getPoint(IID_IPoint, (void**)&piPointOnPoint);
	// if(hr == S_OK)
	// {
		// piPointOnPoint->setX(10);
	// }
	// else if(hr == E_NOINTERFACE)
	// {
		// cout << "IPoint is not implemented on COMPoint" << endl;
		// return 1;
	// }
	// else if(hr == E_FAIL)
	// {
		// cout << "failuer of QueryInterface" << endl;
		// return 1;
	// }
	
	// ILine* piLineOnLine = NULL;
	// HRESULT hr = CATFactory::getLine(IID_ILine, (void**)&piLineOnLine);
	
	
	// IPoint* piPointOnStartPoint = NULL;
	// HRESULT hr_startpoint = CATFactory::getPoint(IID_IPoint, (void**)&piPointOnStartPoint);
	
	// IPoint* piPointOnEndPoint = NULL;
	// HRESULT hr_endpoint = CATFactory::getPoint(IID_IPoint, (void**)&piPointOnEndPoint);
	
	// piPointOnStartPoint->setX(10.0);
	// piPointOnStartPoint->setY(20.0); 
	// piPointOnEndPoint->setX(30.0);
	// piPointOnEndPoint->setY(40.0);

	// piLineOnLine->setStartPoint(piPointOnStartPoint); 
	// piLineOnLine->setEndPoint(piPointOnEndPoint); 
	
	// // IColor* piColorOnLine = NULL;
	// // HRESULT hr_line = piLineOnLine->QueryInterface(IID_IColor, (void**)&piColorOnLine);
	// // piColorOnLine->setRGB(10,20,30);
	
	// IPoint* startPoint = NULL;
	// HRESULT hr1 = piLineOnLine->getStartPoint(startPoint);
	
	// IPoint* endPoint = NULL;
	// HRESULT hr2 =piLineOnLine->getEndPoint(endPoint);
	
	// double startpoint_x = 0;
	// startPoint->getX(startpoint_x);
	// double startpoint_y = 0;
	// startPoint->getY(startpoint_y); 
	
	// double endpoint_x = 0;
	
	// endPoint->getX(endpoint_x);
	// double endpoint_y = 0;
	
	// endPoint->getY(endpoint_y);
	
	
	// std::cout<<"Line has start point: "<<startpoint_x<<" ,"<<startpoint_y<<" and end Point"<<endpoint_x<<" ,"<<endpoint_y<<std::endl;
	
	
    // IPoint* piPointOnLine = NULL;

	// piLineOnLine->QueryInterface(IID_IPoint,(void**)&piPointOnLine);

	// double x,y;
	// piPointOnLine->getX(x);
	// piPointOnLine->getY(y);
	// cout<<"mid point coordinates are respectively are"<<x<<" "<<y<<" "<<endl;
	
	// IPoint* piPointOnPoint=NULL;
	// CATFactory::getPoint(IID_IPoint,(void**)&piPointOnPoint);
	// I3DPoint* pi3DPointonPoint=NULL;
	// HRESULT hr_line = piPointOnPoint->QueryInterface(IID_I3DPoint, (void**)&pi3DPointonPoint);
	// pi3DPointonPoint->setZ(20.0);
	// double z=0;
	// pi3DPointonPoint->getZ(z);
	// cout<<z<<endl;
	/*IPoint* piPointOnPoint = NULL;
	HRESULT hr = CATFactory::getPoint(IID_IPoint, (void**)&piPointOnPoint);
	
	piPointOnPoint->setX(10.0); 
	piPointOnPoint->setY(20.0); 
	
	
	I3DPoint* pi3DPointOnPoint = NULL;
	
	HRESULT hr1 = piPointOnPoint->QueryInterface(IID_I3DPoint, (void**)&pi3DPointOnPoint);
	
	pi3DPointOnPoint->setZ(100.0); 
	
	double zCoord = 0.0; 
	
	pi3DPointOnPoint->getZ(zCoord); 
	
	std::cout<<"The Z coordinate is "<<zCoord<<std::endl;
	
	double z=0; 
	
	pi3DPointOnPoint->getZ(z); 
	
	ILine* piLineOnLine = NULL;
	HRESULT hr2 = CATFactory::getLine(IID_ILine, (void**)&piLineOnLine);
	
	
	IPoint* piPointOnStartPoint = NULL;
	HRESULT hr_startpoint = CATFactory::getPoint(IID_IPoint, (void**)&piPointOnStartPoint);
	
	
	
	IPoint* piPointOnEndPoint = NULL;
	HRESULT hr_endpoint = CATFactory::getPoint(IID_IPoint, (void**)&piPointOnEndPoint);
	
	piPointOnStartPoint->setX(10.0);
	piPointOnStartPoint->setY(20.0);

	I3DPoint* piPointon3DStartPoint = NULL; 
	piPointOnStartPoint->QueryInterface(IID_I3DPoint, (void**)&piPointon3DStartPoint);
	
	piPointon3DStartPoint->setZ(100.0);
	
	piPointOnEndPoint->setX(30.0);
	piPointOnEndPoint->setY(40.0);
	
	I3DPoint* piPointon3DEndPoint = NULL; 
	piPointOnEndPoint->QueryInterface(IID_I3DPoint, (void**)&piPointon3DEndPoint);
	
	piPointon3DEndPoint->setZ(200.0);
	
	
	
	
	piLineOnLine->setStartPoint(piPointOnStartPoint); 
	piLineOnLine->setEndPoint(piPointOnEndPoint);
	
	
	IPoint* piMidPointOnLine = NULL; 
	HRESULT hr_mid = CATFactory::getPoint(IID_IPoint, (void**)&piMidPointOnLine);
	
	std::cout<<"Hi I am here"<<std::endl; 
	piLineOnLine->getMidPoint(piMidPointOnLine);
	
	double midX = 0.0; 
	piMidPointOnLine->getX(midX); 
	
	double midY = 0.0; 
	piMidPointOnLine->getY(midY);
	
	
	
	I3DPoint* pi3DMidPointOnLine = NULL;

	piMidPointOnLine->QueryInterface(IID_I3DPoint, (void**)&pi3DMidPointOnLine);
	
	double midZ = 0.0; 
	pi3DMidPointOnLine->getZ(midZ);
	
	std::cout<<"The midpoint of 3D"<<midX<<", "<<midY<<", "<< midZ <<std::endl;
	*/
	return 0;

}


