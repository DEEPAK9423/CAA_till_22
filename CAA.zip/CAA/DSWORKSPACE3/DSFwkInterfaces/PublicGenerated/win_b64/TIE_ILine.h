#ifndef __TIE_ILine
#define __TIE_ILine

#include <string.h>
#include "CATBaseUnknown.h"
#include "CATMetaClass.h"
#include "CATMacForTie.h"
#include "ILine.h"
#include "JS0DSPA.h"
#include "DSYExport.h"


#define Exported DSYExport
#define Imported DSYImport


/* To link an implementation with the interface ILine */
#define declare_TIE_ILine(classe,TIE_Version) \
 \
      CATForwardDeclareTemplateFunctionSpecialization_##TIE_Version(classe) \
 \
class TIEILine##classe : public ILine \
{ \
   private: \
      CATDeclareCommonTIEMembers2 \
   public: \
      CATDeclareTIEMethods(ILine, classe) \
      CATDeclareIUnknownMethodsForCATBaseUnknownTIE \
      CATDeclareCATBaseUnknownMethodsForTIE \
      virtual HRESULT setStartPoint(IPoint* piPointOnPoint); \
      virtual HRESULT getStartPoint(IPoint* & piPointOnPoint); \
      virtual HRESULT setEndPoint(IPoint* piPointOnPoint); \
      virtual HRESULT getEndPoint(IPoint* & piPointOnPoint); \
      virtual HRESULT getMidPoint(IPoint* &midPoint); \
};



#define ENVTIEdeclare_ILine(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
virtual HRESULT setStartPoint(IPoint* piPointOnPoint); \
virtual HRESULT getStartPoint(IPoint* & piPointOnPoint); \
virtual HRESULT setEndPoint(IPoint* piPointOnPoint); \
virtual HRESULT getEndPoint(IPoint* & piPointOnPoint); \
virtual HRESULT getMidPoint(IPoint* &midPoint); \


#define ENVTIEdefine_ILine(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
HRESULT  ENVTIEName::setStartPoint(IPoint* piPointOnPoint) \
{ \
return (ENVTIECALL(ILine,ENVTIETypeLetter,ENVTIELetter)setStartPoint(piPointOnPoint)); \
} \
HRESULT  ENVTIEName::getStartPoint(IPoint* & piPointOnPoint) \
{ \
return (ENVTIECALL(ILine,ENVTIETypeLetter,ENVTIELetter)getStartPoint(piPointOnPoint)); \
} \
HRESULT  ENVTIEName::setEndPoint(IPoint* piPointOnPoint) \
{ \
return (ENVTIECALL(ILine,ENVTIETypeLetter,ENVTIELetter)setEndPoint(piPointOnPoint)); \
} \
HRESULT  ENVTIEName::getEndPoint(IPoint* & piPointOnPoint) \
{ \
return (ENVTIECALL(ILine,ENVTIETypeLetter,ENVTIELetter)getEndPoint(piPointOnPoint)); \
} \
HRESULT  ENVTIEName::getMidPoint(IPoint* &midPoint) \
{ \
return (ENVTIECALL(ILine,ENVTIETypeLetter,ENVTIELetter)getMidPoint(midPoint)); \
} \


/* Name of the TIE class */
#define class_TIE_ILine(classe)    TIEILine##classe


/* Common methods inside a TIE */
#define common_TIE_ILine(classe,TIE_Version) \
 \
 \
/* Static initialization */ \
CATDefineCommonTIEMembers2(ILine, classe) \
 \
 \
CATImplementTIEMethods(ILine, classe) \
CATImplementIUnknownMethodsForCATBaseUnknownTIE(ILine, classe, 1) \
CATImplementCATBaseUnknownMethodsForTIE(ILine, classe) \
 \
HRESULT  TIEILine##classe::setStartPoint(IPoint* piPointOnPoint) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->setStartPoint(piPointOnPoint)); \
} \
HRESULT  TIEILine##classe::getStartPoint(IPoint* & piPointOnPoint) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->getStartPoint(piPointOnPoint)); \
} \
HRESULT  TIEILine##classe::setEndPoint(IPoint* piPointOnPoint) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->setEndPoint(piPointOnPoint)); \
} \
HRESULT  TIEILine##classe::getEndPoint(IPoint* & piPointOnPoint) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->getEndPoint(piPointOnPoint)); \
} \
HRESULT  TIEILine##classe::getMidPoint(IPoint* &midPoint) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->getMidPoint(midPoint)); \
} \



/* Macro used to link an implementation with an interface */
#define Real_TIE_ILine(classe,TIE_Version) \
 \
 \
declare_TIE_ILine(classe,TIE_Version) \
 \
 \
common_TIE_ILine(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIECreation(ILine, classe) \
 \
 \
CATImplementTIEMeta(ILine, classe, ENUMTypeOfClass::TIE, ILine::MetaObject(), ILine::MetaObject())


/* Macro used to link an implementation with an interface */
/* This TIE is chained on the implementation object */
#define Real_TIEchain_ILine(classe,TIE_Version) \
 \
 \
declare_TIE_ILine(classe,TIE_Version) \
 \
 \
common_TIE_ILine(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIEchainCreation(ILine, classe) \
 \
 \
CATImplementTIEMeta(ILine, classe, ENUMTypeOfClass::TIEchain, ILine::MetaObject(), ILine::MetaObject())

/* Macro to switch between BOA and TIE at build time */ 
#ifdef CATSYS_BOA_IS_TIE
#define BOA_ILine(classe) TIE_ILine(classe)
#else
#define BOA_ILine(classe) CATImplementBOA(ILine, classe)
#endif


/* Macros used to link an implementation with an interface */
#define TIE_Deprecated_ILine(classe) Real_TIE_ILine(classe,TIEV1)
#define TIEchain_Deprecated_ILine(classe) Real_TIEchain_ILine(classe,TIEV1) 
#define TIE_ILine(classe) Real_TIE_ILine(classe,TIEV2)
#define TIEchain_ILine(classe) Real_TIEchain_ILine(classe,TIEV2) 

#endif
