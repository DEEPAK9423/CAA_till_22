#ifndef __TIE_I3DPoint
#define __TIE_I3DPoint

#include <string.h>
#include "CATBaseUnknown.h"
#include "CATMetaClass.h"
#include "CATMacForTie.h"
#include "I3DPoint.h"
#include "JS0DSPA.h"
#include "DSYExport.h"


#define Exported DSYExport
#define Imported DSYImport


/* To link an implementation with the interface I3DPoint */
#define declare_TIE_I3DPoint(classe,TIE_Version) \
 \
      CATForwardDeclareTemplateFunctionSpecialization_##TIE_Version(classe) \
 \
class TIEI3DPoint##classe : public I3DPoint \
{ \
   private: \
      CATDeclareCommonTIEMembers2 \
   public: \
      CATDeclareTIEMethods(I3DPoint, classe) \
      CATDeclareIUnknownMethodsForCATBaseUnknownTIE \
      CATDeclareCATBaseUnknownMethodsForTIE \
      virtual HRESULT setZ(double z); \
      virtual HRESULT getZ(double &z); \
};



#define ENVTIEdeclare_I3DPoint(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
virtual HRESULT setZ(double z); \
virtual HRESULT getZ(double &z); \


#define ENVTIEdefine_I3DPoint(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
HRESULT  ENVTIEName::setZ(double z) \
{ \
return (ENVTIECALL(I3DPoint,ENVTIETypeLetter,ENVTIELetter)setZ(z)); \
} \
HRESULT  ENVTIEName::getZ(double &z) \
{ \
return (ENVTIECALL(I3DPoint,ENVTIETypeLetter,ENVTIELetter)getZ(z)); \
} \


/* Name of the TIE class */
#define class_TIE_I3DPoint(classe)    TIEI3DPoint##classe


/* Common methods inside a TIE */
#define common_TIE_I3DPoint(classe,TIE_Version) \
 \
 \
/* Static initialization */ \
CATDefineCommonTIEMembers2(I3DPoint, classe) \
 \
 \
CATImplementTIEMethods(I3DPoint, classe) \
CATImplementIUnknownMethodsForCATBaseUnknownTIE(I3DPoint, classe, 1) \
CATImplementCATBaseUnknownMethodsForTIE(I3DPoint, classe) \
 \
HRESULT  TIEI3DPoint##classe::setZ(double z) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->setZ(z)); \
} \
HRESULT  TIEI3DPoint##classe::getZ(double &z) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->getZ(z)); \
} \



/* Macro used to link an implementation with an interface */
#define Real_TIE_I3DPoint(classe,TIE_Version) \
 \
 \
declare_TIE_I3DPoint(classe,TIE_Version) \
 \
 \
common_TIE_I3DPoint(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIECreation(I3DPoint, classe) \
 \
 \
CATImplementTIEMeta(I3DPoint, classe, ENUMTypeOfClass::TIE, I3DPoint::MetaObject(), I3DPoint::MetaObject())


/* Macro used to link an implementation with an interface */
/* This TIE is chained on the implementation object */
#define Real_TIEchain_I3DPoint(classe,TIE_Version) \
 \
 \
declare_TIE_I3DPoint(classe,TIE_Version) \
 \
 \
common_TIE_I3DPoint(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIEchainCreation(I3DPoint, classe) \
 \
 \
CATImplementTIEMeta(I3DPoint, classe, ENUMTypeOfClass::TIEchain, I3DPoint::MetaObject(), I3DPoint::MetaObject())

/* Macro to switch between BOA and TIE at build time */ 
#ifdef CATSYS_BOA_IS_TIE
#define BOA_I3DPoint(classe) TIE_I3DPoint(classe)
#else
#define BOA_I3DPoint(classe) CATImplementBOA(I3DPoint, classe)
#endif


/* Macros used to link an implementation with an interface */
#define TIE_Deprecated_I3DPoint(classe) Real_TIE_I3DPoint(classe,TIEV1)
#define TIEchain_Deprecated_I3DPoint(classe) Real_TIEchain_I3DPoint(classe,TIEV1) 
#define TIE_I3DPoint(classe) Real_TIE_I3DPoint(classe,TIEV2)
#define TIEchain_I3DPoint(classe) Real_TIEchain_I3DPoint(classe,TIEV2) 

#endif
