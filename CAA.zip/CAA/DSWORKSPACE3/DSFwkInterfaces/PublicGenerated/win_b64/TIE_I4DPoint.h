#ifndef __TIE_I4DPoint
#define __TIE_I4DPoint

#include <string.h>
#include "CATBaseUnknown.h"
#include "CATMetaClass.h"
#include "CATMacForTie.h"
#include "I4DPoint.h"
#include "JS0DSPA.h"
#include "DSYExport.h"


#define Exported DSYExport
#define Imported DSYImport


/* To link an implementation with the interface I4DPoint */
#define declare_TIE_I4DPoint(classe,TIE_Version) \
 \
      CATForwardDeclareTemplateFunctionSpecialization_##TIE_Version(classe) \
 \
class TIEI4DPoint##classe : public I4DPoint \
{ \
   private: \
      CATDeclareCommonTIEMembers2 \
   public: \
      CATDeclareTIEMethods(I4DPoint, classe) \
      CATDeclareIUnknownMethodsForCATBaseUnknownTIE \
      CATDeclareCATBaseUnknownMethodsForTIE \
      virtual HRESULT setT(double t); \
      virtual HRESULT getT(double &t); \
};



#define ENVTIEdeclare_I4DPoint(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
virtual HRESULT setT(double t); \
virtual HRESULT getT(double &t); \


#define ENVTIEdefine_I4DPoint(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
HRESULT  ENVTIEName::setT(double t) \
{ \
return (ENVTIECALL(I4DPoint,ENVTIETypeLetter,ENVTIELetter)setT(t)); \
} \
HRESULT  ENVTIEName::getT(double &t) \
{ \
return (ENVTIECALL(I4DPoint,ENVTIETypeLetter,ENVTIELetter)getT(t)); \
} \


/* Name of the TIE class */
#define class_TIE_I4DPoint(classe)    TIEI4DPoint##classe


/* Common methods inside a TIE */
#define common_TIE_I4DPoint(classe,TIE_Version) \
 \
 \
/* Static initialization */ \
CATDefineCommonTIEMembers2(I4DPoint, classe) \
 \
 \
CATImplementTIEMethods(I4DPoint, classe) \
CATImplementIUnknownMethodsForCATBaseUnknownTIE(I4DPoint, classe, 1) \
CATImplementCATBaseUnknownMethodsForTIE(I4DPoint, classe) \
 \
HRESULT  TIEI4DPoint##classe::setT(double t) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->setT(t)); \
} \
HRESULT  TIEI4DPoint##classe::getT(double &t) \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->getT(t)); \
} \



/* Macro used to link an implementation with an interface */
#define Real_TIE_I4DPoint(classe,TIE_Version) \
 \
 \
declare_TIE_I4DPoint(classe,TIE_Version) \
 \
 \
common_TIE_I4DPoint(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIECreation(I4DPoint, classe) \
 \
 \
CATImplementTIEMeta(I4DPoint, classe, ENUMTypeOfClass::TIE, I4DPoint::MetaObject(), I4DPoint::MetaObject())


/* Macro used to link an implementation with an interface */
/* This TIE is chained on the implementation object */
#define Real_TIEchain_I4DPoint(classe,TIE_Version) \
 \
 \
declare_TIE_I4DPoint(classe,TIE_Version) \
 \
 \
common_TIE_I4DPoint(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIEchainCreation(I4DPoint, classe) \
 \
 \
CATImplementTIEMeta(I4DPoint, classe, ENUMTypeOfClass::TIEchain, I4DPoint::MetaObject(), I4DPoint::MetaObject())

/* Macro to switch between BOA and TIE at build time */ 
#ifdef CATSYS_BOA_IS_TIE
#define BOA_I4DPoint(classe) TIE_I4DPoint(classe)
#else
#define BOA_I4DPoint(classe) CATImplementBOA(I4DPoint, classe)
#endif


/* Macros used to link an implementation with an interface */
#define TIE_Deprecated_I4DPoint(classe) Real_TIE_I4DPoint(classe,TIEV1)
#define TIEchain_Deprecated_I4DPoint(classe) Real_TIEchain_I4DPoint(classe,TIEV1) 
#define TIE_I4DPoint(classe) Real_TIE_I4DPoint(classe,TIEV2)
#define TIEchain_I4DPoint(classe) Real_TIEchain_I4DPoint(classe,TIEV2) 

#endif
