#ifndef __TIE_IColor
#define __TIE_IColor

#include <string.h>
#include "CATBaseUnknown.h"
#include "CATMetaClass.h"
#include "CATMacForTie.h"
#include "IColor.h"
#include "JS0DSPA.h"
#include "DSYExport.h"


#define Exported DSYExport
#define Imported DSYImport


/* To link an implementation with the interface IColor */
#define declare_TIE_IColor(classe,TIE_Version) \
 \
      CATForwardDeclareTemplateFunctionSpecialization_##TIE_Version(classe) \
 \
class TIEIColor##classe : public IColor \
{ \
   private: \
      CATDeclareCommonTIEMembers2 \
   public: \
      CATDeclareTIEMethods(IColor, classe) \
      CATDeclareIUnknownMethodsForCATBaseUnknownTIE \
      CATDeclareCATBaseUnknownMethodsForTIE \
      virtual HRESULT setRGB(int r, int g, int b) ; \
      virtual HRESULT getRGB(int &r, int &g, int &b) ; \
};



#define ENVTIEdeclare_IColor(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
virtual HRESULT setRGB(int r, int g, int b) ; \
virtual HRESULT getRGB(int &r, int &g, int &b) ; \


#define ENVTIEdefine_IColor(ENVTIEName,ENVTIETypeLetter,ENVTIELetter) \
HRESULT  ENVTIEName::setRGB(int r, int g, int b)  \
{ \
return (ENVTIECALL(IColor,ENVTIETypeLetter,ENVTIELetter)setRGB(r,g,b)); \
} \
HRESULT  ENVTIEName::getRGB(int &r, int &g, int &b)  \
{ \
return (ENVTIECALL(IColor,ENVTIETypeLetter,ENVTIELetter)getRGB(r,g,b)); \
} \


/* Name of the TIE class */
#define class_TIE_IColor(classe)    TIEIColor##classe


/* Common methods inside a TIE */
#define common_TIE_IColor(classe,TIE_Version) \
 \
 \
/* Static initialization */ \
CATDefineCommonTIEMembers2(IColor, classe) \
 \
 \
CATImplementTIEMethods(IColor, classe) \
CATImplementIUnknownMethodsForCATBaseUnknownTIE(IColor, classe, 1) \
CATImplementCATBaseUnknownMethodsForTIE(IColor, classe) \
 \
HRESULT  TIEIColor##classe::setRGB(int r, int g, int b)  \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->setRGB(r,g,b)); \
} \
HRESULT  TIEIColor##classe::getRGB(int &r, int &g, int &b)  \
{ \
   return(((classe *)Tie_Method_##TIE_Version(NecessaryData.ForTIE,ptstat,classe))->getRGB(r,g,b)); \
} \



/* Macro used to link an implementation with an interface */
#define Real_TIE_IColor(classe,TIE_Version) \
 \
 \
declare_TIE_IColor(classe,TIE_Version) \
 \
 \
common_TIE_IColor(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIECreation(IColor, classe) \
 \
 \
CATImplementTIEMeta(IColor, classe, ENUMTypeOfClass::TIE, IColor::MetaObject(), IColor::MetaObject())


/* Macro used to link an implementation with an interface */
/* This TIE is chained on the implementation object */
#define Real_TIEchain_IColor(classe,TIE_Version) \
 \
 \
declare_TIE_IColor(classe,TIE_Version) \
 \
 \
common_TIE_IColor(classe,TIE_Version) \
 \
 \
/* creator function of the interface */ \
/* encapsulate the new */ \
CATImplementTIEchainCreation(IColor, classe) \
 \
 \
CATImplementTIEMeta(IColor, classe, ENUMTypeOfClass::TIEchain, IColor::MetaObject(), IColor::MetaObject())

/* Macro to switch between BOA and TIE at build time */ 
#ifdef CATSYS_BOA_IS_TIE
#define BOA_IColor(classe) TIE_IColor(classe)
#else
#define BOA_IColor(classe) CATImplementBOA(IColor, classe)
#endif


/* Macros used to link an implementation with an interface */
#define TIE_Deprecated_IColor(classe) Real_TIE_IColor(classe,TIEV1)
#define TIEchain_Deprecated_IColor(classe) Real_TIEchain_IColor(classe,TIEV1) 
#define TIE_IColor(classe) Real_TIE_IColor(classe,TIEV2)
#define TIEchain_IColor(classe) Real_TIEchain_IColor(classe,TIEV2) 

#endif
