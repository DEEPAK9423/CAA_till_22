#ifndef ExportedByDSItfModule_H
#define ExportedByDSItfModule_H
#if defined(__DSItfModule)
# define ExportedByDSItfModule   DSYExport
#else // __DSModule4
# define ExportedByDSItfModule   DSYImport
#endif  // __DSModule4
#include "DSYExport.h"
#endif //ExportedByDSItfModule_H 