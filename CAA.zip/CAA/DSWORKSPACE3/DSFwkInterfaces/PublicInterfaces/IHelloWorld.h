#pragma once
#include"DSItfModule.h"

class ExportedByDSItfModule IHelloWorld
{
public:
  virtual void greet()=0;
};