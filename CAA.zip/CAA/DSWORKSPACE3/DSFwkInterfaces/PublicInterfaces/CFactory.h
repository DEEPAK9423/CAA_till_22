#pragma once
#include"DSItfModule.h"
#include "IHelloWorld.h"
#include"CHelloWorld.h"

class ExportedByDSItfModule CFactory
{
	public:
  static IHelloWorld* getHelloWorld();
};